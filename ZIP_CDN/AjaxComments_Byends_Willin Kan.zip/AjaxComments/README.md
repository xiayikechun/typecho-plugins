### 嵌套评论ajax提交AjaxComments v1.2.0

jquery实现typecho原生嵌套评论的异步提交效果，后台设置好对应元素id或class即可。

 > 修正描述与php5.6报错问题。
