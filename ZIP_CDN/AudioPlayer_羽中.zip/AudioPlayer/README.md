### Typecho音乐播放器插件AudioPlayer
2018年6月27日更新至**v1.2.6**: 
- 缺省调用mb.miniAudioPlayer
- HTML5版支持配色/列表模式
- HTML5版支持ID3及解密播放
- 新增编辑器按钮重整文件结构

#### 详细说明与效果演示见blog发布地址: 
 > http://www.yzmb.me/archives/net/audio-player-for-typecho