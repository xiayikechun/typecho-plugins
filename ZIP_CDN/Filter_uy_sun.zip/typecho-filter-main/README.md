# Filter

首页过滤加密文章和评论

## 安装

下载插件，修改文件夹为 Filter，上传到网站插件目录，后台启用。

```bash
cd typecho/usr/plugins
git clone https://github.com/he0119/typecho-filter.git Filter
```
